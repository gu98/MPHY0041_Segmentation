# datasets

Small data sets for demo, coursework, tutorials etc.

N.B. individual data sets are in branches and can be accessed via:
git clone -b mydataset --single-branch https://weisslab.cs.ucl.ac.uk/WEISSTeaching/datasets.git